@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ebay.com/marketplace/services", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ebay.marketplace.services;
